<html>
    <head>
    <title>Search</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
<header>
<h3>Search for Products</h3>
</header>
<form action="phpSearch.php" method="post">
Search <input type="text" name="search"><br>
<input type ="submit">
</form>

</body>
</html>