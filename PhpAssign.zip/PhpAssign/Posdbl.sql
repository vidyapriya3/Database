/*
SQLyog Enterprise v13.1.1 (32 bit)
MySQL - 8.0.25 : Database - posdb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`posdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `posdb`;

/*Table structure for table `itemcategory` */

DROP TABLE IF EXISTS `itemcategory`;

CREATE TABLE `itemcategory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;

/*Data for the table `itemcategory` */

insert  into `itemcategory`(`ID`,`NAME`) values 
(27,'AOB'),
(20,'Beddings'),
(21,'Clothes'),
(19,'Kitchenware');

/*Table structure for table `itemgroup` */

DROP TABLE IF EXISTS `itemgroup`;

CREATE TABLE `itemgroup` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GroupName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CATEGORY_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`GroupName`),
  KEY `ID` (`ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  CONSTRAINT `itemgroup_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `itemcategory` (`NAME`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb3;

/*Data for the table `itemgroup` */

insert  into `itemgroup`(`ID`,`GroupName`,`CATEGORY_ID`) values 
(55,'bags','Clothes'),
(67,'balls','AOB'),
(60,'blankets','Beddings'),
(50,'chopping board','Kitchenware'),
(41,'Knives','Kitchenware'),
(28,'Plates','Kitchenware'),
(33,'Spoons','Kitchenware');

/*Table structure for table `menuitem` */

DROP TABLE IF EXISTS `menuitem`;

CREATE TABLE `menuitem` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL,
  `GROUP_ID` varchar(50) DEFAULT NULL,
  `BARCODE` varchar(120) DEFAULT NULL,
  `BUY_PRICE` double NOT NULL,
  `STOCK_AMOUNT` double DEFAULT NULL,
  `PRICE` double(10,2) NOT NULL,
  `TAX_ID` int DEFAULT NULL,
  PRIMARY KEY (`NAME`),
  KEY `ID` (`ID`),
  KEY `GROUP_ID` (`GROUP_ID`),
  KEY `TAX_ID` (`TAX_ID`),
  KEY `index_Barcode` (`BARCODE`),
  CONSTRAINT `menuitem_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `itemgroup` (`GroupName`) ON UPDATE CASCADE,
  CONSTRAINT `menuitem_ibfk_2` FOREIGN KEY (`TAX_ID`) REFERENCES `tax` (`ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=utf8mb3;

/*Data for the table `menuitem` */

insert  into `menuitem`(`ID`,`NAME`,`GROUP_ID`,`BARCODE`,`BUY_PRICE`,`STOCK_AMOUNT`,`PRICE`,`TAX_ID`) values 
(331,'big ball','balls',NULL,200,22,300.00,2),
(295,'hand bag','bags',NULL,250,33,500.00,2),
(240,'kitchen small Knives','Knives',NULL,80,17,120.00,2),
(104,'Line plate','Plates',NULL,125,60,150.00,2),
(276,'proffesional','chopping board',NULL,250,7,350.00,2),
(251,'Serviet holder uniq','Spoons',NULL,400,4,700.00,2),
(313,'soft throw','blankets',NULL,550,10,1000.00,2),
(337,'tennis','balls',NULL,30,46,50.00,2);

/*Table structure for table `sale` */

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `TransactionNo` int NOT NULL,
  `ItemName` varchar(120) DEFAULT NULL,
  `CREATE_DATE` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `SETTLED` enum('Yes','No') DEFAULT 'No',
  `BuyingPrice` double(10,2) DEFAULT NULL,
  `SellingPrice` double(10,2) DEFAULT NULL,
  `Units` int DEFAULT '1',
  `STATUS` varchar(30) DEFAULT NULL,
  `OWNER_ID` int DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `SaleType` enum('Credit Sale','Cash Sale') DEFAULT 'Cash Sale',
  `Customer` text,
  PRIMARY KEY (`ID`),
  KEY `ticketcreateDate` (`CREATE_DATE`),
  KEY `ticketsettled` (`SETTLED`),
  KEY `FK937B5F0CAA075D69` (`OWNER_ID`),
  KEY `index_itemName` (`ItemName`),
  KEY `index_Settled` (`SETTLED`),
  CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`ItemName`) REFERENCES `menuitem` (`NAME`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb3;

/*Data for the table `sale` */

insert  into `sale`(`ID`,`TransactionNo`,`ItemName`,`CREATE_DATE`,`SETTLED`,`BuyingPrice`,`SellingPrice`,`Units`,`STATUS`,`OWNER_ID`,`tax`,`SaleType`,`Customer`) values 
(186,5,'big ball','2020-04-03 07:20:08','No',200.00,300.00,1,NULL,7,0,'Cash Sale',NULL),
(187,6,'kitchen small Knives','2020-04-03 07:26:02','No',80.00,120.00,1,NULL,7,0,'Cash Sale',NULL),
(189,8,'proffesional','2020-04-03 07:35:15','Yes',250.00,350.00,1,NULL,7,0,'Cash Sale',NULL),
(190,9,'big ball','2020-04-03 07:38:50','Yes',200.00,300.00,1,NULL,7,0,'Cash Sale',NULL),
(191,10,'Line plate','2020-04-03 07:44:07','Yes',125.00,150.00,1,NULL,7,0,'Cash Sale',NULL),
(192,11,'hand bag','2020-04-03 07:46:12','Yes',250.00,500.00,1,NULL,7,0,'Cash Sale',NULL),
(193,12,'hand bag','2020-04-03 07:48:13','Yes',250.00,500.00,1,NULL,7,0,'Cash Sale',NULL),
(194,13,'soft throw','2020-04-03 07:52:44','Yes',550.00,1000.00,2,NULL,7,0,'Cash Sale',NULL),
(195,14,'tennis','2020-04-03 08:06:47','Yes',30.00,50.00,1,NULL,7,0,'Cash Sale',NULL);

/*Table structure for table `tax` */

DROP TABLE IF EXISTS `tax`;

CREATE TABLE `tax` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(20) NOT NULL,
  `RATE` double DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

/*Data for the table `tax` */

insert  into `tax`(`ID`,`NAME`,`RATE`) values 
(1,'General Rate',16),
(2,'Zero Rated',0),
(3,'Exempted',0);

/*Table structure for table `tblactivemodules` */

DROP TABLE IF EXISTS `tblactivemodules`;

CREATE TABLE `tblactivemodules` (
  `Messaging` enum('Yes','No') NOT NULL DEFAULT 'No',
  `Finance` enum('Yes','No') NOT NULL DEFAULT 'No',
  `Modem` enum('Yes','No') NOT NULL DEFAULT 'No',
  `API` enum('Yes','No') NOT NULL DEFAULT 'No',
  `BoysSchool` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `GirlsSchool` enum('yes','No') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`Messaging`,`Finance`,`Modem`,`API`,`BoysSchool`,`GirlsSchool`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Data for the table `tblactivemodules` */

/*Table structure for table `tblbusinessdetails` */

DROP TABLE IF EXISTS `tblbusinessdetails`;

CREATE TABLE `tblbusinessdetails` (
  `NameOfBusiness` varchar(100) NOT NULL,
  `PostalAdress` varchar(100) DEFAULT NULL,
  `OfficeContacts` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`NameOfBusiness`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblbusinessdetails` */

insert  into `tblbusinessdetails`(`NameOfBusiness`,`PostalAdress`,`OfficeContacts`) values 
('BrightMatt','123 Kabarnet','92736353553');

/*Table structure for table `tblcustomers` */

DROP TABLE IF EXISTS `tblcustomers`;

CREATE TABLE `tblcustomers` (
  `CustomerId` int NOT NULL AUTO_INCREMENT COMMENT 'houses the tsc number of a given teacher in a school',
  `Fname` varchar(50) NOT NULL,
  `Mname` varchar(50) DEFAULT NULL,
  `Lname` varchar(50) NOT NULL,
  `NationalD` int DEFAULT NULL COMMENT 'Houses the National id card number of a guardian of given student',
  `Contacts` varchar(50) DEFAULT NULL,
  `Title` varchar(10) DEFAULT NULL,
  `Department` varchar(50) NOT NULL DEFAULT 'Teaching',
  `Email` varchar(100) DEFAULT NULL,
  `CompanyName` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CustomerId`),
  UNIQUE KEY `TscNo` (`CustomerId`),
  UNIQUE KEY `NationalD` (`NationalD`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblcustomers` */

/*Table structure for table `tblstaff` */

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `EmployeeId` int NOT NULL COMMENT 'houses the tsc number of a given teacher in a school',
  `Fname` varchar(50) NOT NULL,
  `Mname` varchar(50) DEFAULT NULL,
  `Lname` varchar(50) NOT NULL,
  `NationalD` int DEFAULT NULL COMMENT 'Houses the National id card number of a guardian of given student',
  `Contacts` varchar(50) DEFAULT NULL,
  `Title` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`EmployeeId`),
  UNIQUE KEY `TscNo` (`EmployeeId`),
  UNIQUE KEY `NationalD` (`NationalD`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblstaff` */

insert  into `tblstaff`(`EmployeeId`,`Fname`,`Mname`,`Lname`,`NationalD`,`Contacts`,`Title`) values 
(1,'MELLEN','N','NYABERI',1,'0713915303','Ms'),
(7,'NANCY','','MESOCHO',2,'','Ms');

/*Table structure for table `tblstock` */

DROP TABLE IF EXISTS `tblstock`;

CREATE TABLE `tblstock` (
  `Item` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `StockAmount` int DEFAULT NULL,
  PRIMARY KEY (`Item`,`Date`),
  CONSTRAINT `tblstock_ibfk_1` FOREIGN KEY (`Item`) REFERENCES `menuitem` (`NAME`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*Data for the table `tblstock` */

/*Table structure for table `tbluser` */

DROP TABLE IF EXISTS `tbluser`;

CREATE TABLE `tbluser` (
  `UserName` varchar(50) NOT NULL COMMENT 'This is the name used logging into the system',
  `Password` varchar(50) NOT NULL COMMENT 'This is a secret key used logging into the system',
  `Userlevel` enum('Administrator','MANAGER','SR. CASHIER','CASHIER','Waiter','Cook') NOT NULL,
  `EmployeeId` int DEFAULT NULL,
  PRIMARY KEY (`Password`),
  UNIQUE KEY `teacherId_2` (`EmployeeId`),
  CONSTRAINT `tbluser_ibfk_9` FOREIGN KEY (`EmployeeId`) REFERENCES `tblstaff` (`EmployeeId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbluser` */

insert  into `tbluser`(`UserName`,`Password`,`Userlevel`,`EmployeeId`) values 
('ngeresa','1111','Administrator',1),
('ongeri','2890','CASHIER',7);

/*Table structure for table `tbluserlog` */

DROP TABLE IF EXISTS `tbluserlog`;

CREATE TABLE `tbluserlog` (
  `ActionId` bigint NOT NULL,
  `User` varchar(50) DEFAULT NULL,
  `ActionType` enum('Add Stock','Reset Stock','Delete Item','Delete Sale') DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ActionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `tbluserlog` */

/*Table structure for table `user_type` */

DROP TABLE IF EXISTS `user_type`;

CREATE TABLE `user_type` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `P_NAME` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

/*Data for the table `user_type` */

insert  into `user_type`(`ID`,`P_NAME`) values 
(1,'Administrator'),
(2,'MANAGER'),
(3,'CASHIER'),
(4,'SR. CASHIER');

/* Trigger structure for table `sale` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trgUpdateStock` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `trgUpdateStock` AFTER INSERT ON `sale` FOR EACH ROW BEGIN
UPDATE menuitem SET stock_amount=STOCK_AMOUNT-NEW.UNITS;
    END */$$


DELIMITER ;

/*Table structure for table `vwmenuitems` */

DROP TABLE IF EXISTS `vwmenuitems`;

/*!50001 DROP VIEW IF EXISTS `vwmenuitems` */;
/*!50001 DROP TABLE IF EXISTS `vwmenuitems` */;

/*!50001 CREATE TABLE  `vwmenuitems`(
 `ID` int ,
 `MenuItem` varchar(50) ,
 `BARCODE` varchar(120) ,
 `BPincVAT` double ,
 `BUY_PRICE` double ,
 `SPincVAT` double ,
 `Price` double ,
 `itemGroup` varchar(50) ,
 `Category` varchar(50) 
)*/;

/*Table structure for table `vwsales` */

DROP TABLE IF EXISTS `vwsales`;

/*!50001 DROP VIEW IF EXISTS `vwsales` */;
/*!50001 DROP TABLE IF EXISTS `vwsales` */;

/*!50001 CREATE TABLE  `vwsales`(
 `TransactionNo` int ,
 `ItemName` varchar(120) ,
 `Barcode` varchar(120) ,
 `units` int ,
 `CREATE_DATE` timestamp ,
 `Settled` enum('Yes','No') ,
 `OWNER_ID` int ,
 `BP_inc_VAT` double(10,2) ,
 `BuyingPrice` double ,
 `Input_Vat` double ,
 `SP_inc_VAT` double(10,2) ,
 `SellingPrice` double ,
 `OutPut_Vat` double ,
 `Net_VAT` double ,
 `profit` double 
)*/;

/*View structure for view vwmenuitems */

/*!50001 DROP TABLE IF EXISTS `vwmenuitems` */;
/*!50001 DROP VIEW IF EXISTS `vwmenuitems` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwmenuitems` AS select `menuitem`.`ID` AS `ID`,`menuitem`.`NAME` AS `MenuItem`,`menuitem`.`BARCODE` AS `BARCODE`,round(`menuitem`.`BUY_PRICE`,2) AS `BPincVAT`,round(if((`tax`.`RATE` > 0),((100 * `menuitem`.`BUY_PRICE`) / (100 + `tax`.`RATE`)),`menuitem`.`BUY_PRICE`),2) AS `BUY_PRICE`,round(`menuitem`.`PRICE`,2) AS `SPincVAT`,round(if((`tax`.`RATE` > 0),((100 * `menuitem`.`PRICE`) / (100 + `tax`.`RATE`)),`menuitem`.`PRICE`),2) AS `Price`,`itemgroup`.`GroupName` AS `itemGroup`,`itemcategory`.`NAME` AS `Category` from (((`itemcategory` join `itemgroup`) join `menuitem`) join `tax`) where ((`itemcategory`.`NAME` = `itemgroup`.`CATEGORY_ID`) and (`itemgroup`.`GroupName` = `menuitem`.`GROUP_ID`) and (`menuitem`.`TAX_ID` = `tax`.`ID`)) */;

/*View structure for view vwsales */

/*!50001 DROP TABLE IF EXISTS `vwsales` */;
/*!50001 DROP VIEW IF EXISTS `vwsales` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwsales` AS select `sale`.`TransactionNo` AS `TransactionNo`,`sale`.`ItemName` AS `ItemName`,`menuitem`.`BARCODE` AS `Barcode`,`sale`.`Units` AS `units`,`sale`.`CREATE_DATE` AS `CREATE_DATE`,`sale`.`SETTLED` AS `Settled`,`sale`.`OWNER_ID` AS `OWNER_ID`,`sale`.`BuyingPrice` AS `BP_inc_VAT`,round(if((`sale`.`tax` > 0),((100 * `sale`.`BuyingPrice`) / (100 + `sale`.`tax`)),`sale`.`BuyingPrice`),2) AS `BuyingPrice`,round((`sale`.`BuyingPrice` - if((`sale`.`tax` > 0),((100 * `sale`.`BuyingPrice`) / (100 + `sale`.`tax`)),`sale`.`BuyingPrice`)),2) AS `Input_Vat`,`sale`.`SellingPrice` AS `SP_inc_VAT`,round(if((`sale`.`tax` > 0),((100 * `sale`.`SellingPrice`) / (100 + `sale`.`tax`)),`sale`.`SellingPrice`),2) AS `SellingPrice`,round((`sale`.`SellingPrice` - if((`sale`.`tax` > 0),((100 * `sale`.`SellingPrice`) / (100 + `sale`.`tax`)),`sale`.`SellingPrice`)),2) AS `OutPut_Vat`,round(((`sale`.`SellingPrice` - if((`sale`.`tax` > 0),((100 * `sale`.`SellingPrice`) / (100 + `sale`.`tax`)),`sale`.`SellingPrice`)) - (`sale`.`BuyingPrice` - if((`sale`.`tax` > 0),((100 * `sale`.`BuyingPrice`) / (100 + `sale`.`tax`)),`sale`.`BuyingPrice`))),2) AS `Net_VAT`,round((`sale`.`SellingPrice` - `sale`.`BuyingPrice`),2) AS `profit` from (`sale` join `menuitem`) where (`menuitem`.`NAME` = `sale`.`ItemName`) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
