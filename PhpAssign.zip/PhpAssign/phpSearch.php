<html>
    <head>
    <title>Search</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
<header>
<h3>Search Results</h3>
</header>
    <?php

$search = $_POST['search'];

$servername = "localhost";
$username = "ShopOwner";
$password = "ShopOwner";
$db = "PosDb";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select ItemName as 'Item Name',sum(units) as 'Units',sum(BuyingPrice)as 'Buying Price',"
        . "sum(SellingPrice)as 'Selling Price',(sum(SellingPrice)-sum(BuyingPrice)) as Profit "
        . "from sale where ItemName like '%$search%' "
        . "group by ItemName order by sum(SellingPrice)";

$result = $conn->query($sql);

if ($result->num_rows > 0){
            echo "<table id=salesTable>";
            echo "<tr>";
                echo "<th>Item Name</th>";
                echo "<th>Units</th>";
                echo "<th>Buying Price</th>";
                echo "<th>Selling Price</th>";
                echo "<th>Profit</th>";
            echo "</tr>";
while($row = $result->fetch_assoc() ){
	echo "<tr>";
        echo "<td>" . $row['Item Name'] . "</td>";
        echo "<td>" . $row['Units'] . "</td>";
        echo "<td>" . $row['Buying Price'] . "</td>";
        echo "<td>" . $row['Selling Price'] . "</td>";
        echo "<td>" . $row['Profit'] . "</td>";
        echo "</tr>";
}
echo "</table>";
} else {
	echo "0 records";
}

$conn->close();

?>
</html>